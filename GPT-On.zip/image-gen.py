import requests

API_URL = "https://api-inference.huggingface.co/models/prompthero/openjourney"
headers = {"Authorization": "Bearer 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"}
que = input("> ")

def query(payload):
	response = requests.post(API_URL, headers=headers, json=payload)
	return response.content
image_bytes = query({
	"inputs": que,
})
# You can access the image with PIL.Image for example
import io
from PIL import Image
image = Image.open(io.BytesIO(image_bytes))


# Create a session object
sess = requests.Session()

# Set the authorization header for the session
sess.headers = {"Authorization": "Bearer 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"}

def query(payload):
    # Use the session object to send the request
    response = sess.post(API_URL, json=payload)
    return response.content


qi = que.replace(" ", "_")
emulated_name = "GENERATIVE-User-" + qi + ".jpg"
# Save the image to a file
with open("./generated/" + emulated_name, "wb") as f:
    f.write(image_bytes)