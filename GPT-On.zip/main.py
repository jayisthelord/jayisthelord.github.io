from hugchat import hugchat
from hugchat.login import Login
import time

import requests
import io
from PIL import Image

import discord
from discord.ext import commands

bot = commands.Bot(command_prefix="",
                   intents=discord.Intents().all())

sign = Login("kuba.devmail@icloud.com", "Kuba2009@")
cookies = sign.login()

cookie_path_dir = "./GPT-On/cookies"
sign.saveCookiesToDir(cookie_path_dir)
chatbot = hugchat.ChatBot(cookies=cookies.get_dict()) 

API_URL = "https://api-inference.huggingface.co/models/prompthero/openjourney"
headers = {"Authorization": "Bearer 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"}

def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.content

@bot.event
async def on_ready():
    await bot.change_presence(activity=discord.Streaming(name="GPT-3 Based!", url="https://twitch.tv/8bitAI"))

@bot.command()
async def bitimg(ctx, *, message: str):
    payload = {
        "inputs": f"<{message}>",
    }
    image_bytes = query(payload)
    # Save the image to disk
    with open("generated_image.png", "wb") as f:
        f.write(image_bytes)
    # Share the image via Discord
    embed = discord.Embed(title="",
                          description="**bit** > Generating", color=0xCC6B49)   
    attachment = discord.File(fp="generated_image.png", filename="generated_image.png")
    await ctx.send(file=attachment)



@bot.event
async def on_message(message):
    id = chatbot.new_conversation()
    chatbot.change_conversation(id)
    q = message.content

    reply_author = None if message.reference is None or bot.get_channel(message.reference.channel_id) is None  \
        else (await bot.get_channel(message.reference.channel_id).fetch_message(message.reference.message_id)).author
    if bot.user in message.mentions and reply_author == bot.user:
        gene_emb = discord.Embed(title="",
                             description=" ",
                             color=0xCC6B49)
        gene_emb.set_author(name="8-bit AI",
                            icon_url="https://firebasestorage.googleapis.com/v0/b/dll-1fe73.appspot.com/o/Tempo%20(Dark).png?alt=media&token=108d8a94-fc20-4bdf-9ac0-d85f79da158d")
        
        
        genmsg = await message.channel.send(embed=gene_emb)
        que = chatbot.chat(q)
        gener_emb = discord.Embed(title="",
                                description=f"**bit** > {que}",
                                color=0xD2A24C)
        gener_emb.set_author(name="8-bit AI",
                            icon_url="https://firebasestorage.googleapis.com/v0/b/dll-1fe73.appspot.com/o/sTempo%20(Dark).png?alt=media&token=f08dc594-2a88-486f-adca-c890a60ac0c6")

        time.sleep(0.1)
        await genmsg.edit(embed=gener_emb)

    await bot.process_commands(message)

@bot.command()
async def bit(ctx, *, q):
    id = chatbot.new_conversation()
    chatbot.change_conversation(id)

    gene_emb = discord.Embed(title="",
                             description=" ",
                             color=0xCC6B49)
    gene_emb.set_author(name="8-bit AI",
                        icon_url="https://firebasestorage.googleapis.com/v0/b/dll-1fe73.appspot.com/o/Tempo%20(Dark).png?alt=media&token=108d8a94-fc20-4bdf-9ac0-d85f79da158d")
    
    
    genmsg = await ctx.send(embed=gene_emb)
    que = chatbot.chat(q)
    gener_emb = discord.Embed(title="",
                             description=f"**bit** > {que}",
                             color=0xD2A24C)
    gener_emb.set_author(name="8-bit AI",
                        icon_url="https://firebasestorage.googleapis.com/v0/b/dll-1fe73.appspot.com/o/sTempo%20(Dark).png?alt=media&token=f08dc594-2a88-486f-adca-c890a60ac0c6")

    time.sleep(0.1)
    await genmsg.edit(embed=gener_emb)

@bot.command()
@commands.is_owner()
async def devchat(ctx, *, q):
    id = chatbot.new_conversation()
    chatbot.change_conversation(id)
    que = chatbot.chat(q)

    await ctx.send(que)


bot.run("MTE0MjQwOTQ2NDQyNzgzOTYzMA.G-fmwf.VwsKCWlkOT_WYG_4qeHzlS6VzSj2Wd3n11F_RY")